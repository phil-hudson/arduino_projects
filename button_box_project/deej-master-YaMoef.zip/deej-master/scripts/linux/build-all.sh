#!/bin/sh

echo 'Building deej (all)...'

./build-dev.sh
./build-release.sh
